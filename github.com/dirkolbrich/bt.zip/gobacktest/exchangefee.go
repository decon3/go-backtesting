package gobacktest

import (
// "fmt"
)

// ExchangeFeeHandler is the basic interface for managing the exchange fee
type ExchangeFeeHandler interface {
	Fee(qty int64, price float64) (float64, error)
}

// FixedExchangeFee returns a fixed exchange fee
type FixedExchangeFee struct {
	ExchangeFee float64
}

// PercentageExchangeFee returns a percentage of price as exchange fee
type PercentageExchangeFee struct {
	ExchangeFee float64
}

// Fee returns the set exchange fee of the trade
func (e *FixedExchangeFee) Fee(qty int64, price float64) (float64, error) {
	return e.ExchangeFee, nil
}

// Fee returns the exchange fee of the trade based on price
func (e *PercentageExchangeFee) Fee(qty int64, price float64) (float64, error) {
	return e.ExchangeFee * float64(qty) * price, nil
}
