package gobacktest

import (
// "fmt"
)

// ExchangeFeeHandler is the basic interface for managing the exchange fee
type TransactionTaxHandler interface {
	Calculate(qty int64, price float64) (float64, error)
}

// TransactionTax returns a set tax
type FixedTransactionTax struct {
	Tax float64
}

// Tax returns a set tax on the trade
func (e *FixedTransactionTax) Calculate(qty int64, price float64) (float64, error) {
	return e.Tax, nil
}

// PercentageTransactionTax returns tax as a percentage on price
type PercentageTransactionTax struct {
	Tax float64
}

// Tax returns tax as a percentage on price
func (e *PercentageTransactionTax) Calculate(qty int64, price float64) (float64, error) {
	return e.Tax * float64(qty) * price, nil
}
