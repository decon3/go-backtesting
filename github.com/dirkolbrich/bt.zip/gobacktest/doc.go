// Copyright 2017 Dirk Olbrich.  All rights reserved.
// Use of this source code is governed by a MIT-style
// license that can be found in the LICENSE file.

// Package gobacktest is a simple placeholder to root all gobacktest documentation
package gobacktest // import "github.com/dirkolbrich/gobacktest"
