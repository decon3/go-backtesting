package algo

import (
	"fmt"

	gbt "github.com/dirkolbrich/gobacktest"
	"github.com/dirkolbrich/gobacktest/ta"
)

/* SMA */

// smaAlgo is an algo which calculates the simple moving average.
type smaAlgo struct {
	gbt.Algo
	period int
	sma    float64
}

// SMA returns a sma algo ready to use.
func SMA(i int) gbt.AlgoHandler {
	return &smaAlgo{period: i}
}

// Run runs the algo.
func (a *smaAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	data, _ := s.Data()
	event, _ := s.Event()
	symbol := event.Symbol()

	// prepare list of floats
	list := data.List(symbol)
	var values []float64

	if len(list) < a.period {
		return false, fmt.Errorf("invalid value length for indicator sma")
	}

	for i := 0; i < a.period; i++ {
		values = append(values, list[len(list)-i-1].Price())
	}

	// calculate SMA
	smas := ta.Sma(values, a.period)
	if len(smas) > 0 {
		a.sma = smas[len(smas)-1]
		// save the calculated sma to the event metrics
		event.Add(fmt.Sprintf("SMA%d", a.period), a.sma)

		return true, nil
	}
	return false, fmt.Errorf("no sma calculated")
}

// Value returns the value of this Algo.
func (a *smaAlgo) Value() float64 {
	return a.sma
}

/* EMA */

// emaAlgo is an algo which calculates the simple moving average.
type emaAlgo struct {
	gbt.Algo
	period int
	ema    float64
}

// eMA returns a ema algo ready to use.
func EMA(i int) gbt.AlgoHandler {
	return &emaAlgo{period: i}
}

// Run runs the algo.
func (a *emaAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	data, _ := s.Data()
	event, _ := s.Event()
	symbol := event.Symbol()

	// prepare list of floats
	list := data.List(symbol)
	var values []float64

	if len(list) < a.period {
		return false, fmt.Errorf("invalid value length for indicator ema")
	}

	for i := 0; i < a.period; i++ {
		values = append(values, list[len(list)-i-1].Price())
	}

	// calculate EMA
	emas := ta.Ema(values, a.period)
	if len(emas) > 0 {
		a.ema = emas[len(emas)-1]
		// save the calculated ema to the event metrics
		event.Add(fmt.Sprintf("EMA%d", a.period), a.ema)

		return true, nil
	}
	return false, fmt.Errorf("no ema calculated")
}

// Value returns the value of this Algo.
func (a *emaAlgo) Value() float64 {
	return a.ema
}

/* ATR */

// atrAlgo is an algo which calculates the simple moving average.
type atrAlgo struct {
	gbt.Algo
	period int
	atr    float64
}

// atr returns a atr algo ready to use.
func ATR(i int) gbt.AlgoHandler {
	return &atrAlgo{period: i}
}

// Run runs the algo.
func (a *atrAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	data, _ := s.Data()
	event, _ := s.Event()
	symbol := event.Symbol()

	// prepare list of floats
	list := data.List(symbol)
	var closes []float64
	var highs []float64
	var lows []float64

	if len(list) < a.period {
		return false, fmt.Errorf("invalid value length for indicator atr")
	}

	for i := 0; i < a.period; i++ {
		closes = append(closes, list[len(list)-i-1].Price())
		highs = append(highs, list[len(list)-i-1].DayHigh())
		lows = append(lows, list[len(list)-i-1].DayLow())
	}

	// calculate atr
	atrs := ta.Atr(highs, lows, closes, a.period)
	if len(atrs) > 0 {
		a.atr = atrs[len(atrs)-1]
		// save the calculated atr to the event metrics
		event.Add(fmt.Sprintf("atr%d", a.period), a.atr)

		return true, nil
	}
	return false, fmt.Errorf("no atr calculated")
}

// Value returns the value of this Algo.
func (a *atrAlgo) Value() float64 {
	return a.atr
}

/* RSI */

// rsiAlgo is an algo which calculates the simple moving average.
type rsiAlgo struct {
	gbt.Algo
	period int
	rsi    float64
}

// RSI returns a rsi algo ready to use.
func RSI(i int) gbt.AlgoHandler {
	return &rsiAlgo{period: i}
}

// Run runs the algo.
func (a *rsiAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	data, _ := s.Data()
	event, _ := s.Event()
	symbol := event.Symbol()

	// prepare list of floats
	list := data.List(symbol)
	var closes []float64

	if len(list) < a.period {
		return false, fmt.Errorf("invalid value length for indicator rsi")
	}

	for i := 0; i < a.period; i++ {
		closes = append(closes, list[len(list)-i-1].Price())
	}

	// calculate rsi
	rsis := ta.Rsi(closes, a.period)
	if len(rsis) > 0 {
		a.rsi = rsis[len(rsis)-1]
		// save the calculated rsi to the event metrics
		event.Add(fmt.Sprintf("rsi%d", a.period), a.rsi)

		return true, nil
	}
	return false, fmt.Errorf("no rsi calculated")
}

// Value returns the value of this Algo.
func (a *rsiAlgo) Value() float64 {
	return a.rsi
}

/* Momentum */

// momentumAlgo is an algo which calculates the simple moving average.
type momentumAlgo struct {
	gbt.Algo
	period   int
	momentum float64
}

// Momentum returns a momentum algo ready to use.
func Momentum(i int) gbt.AlgoHandler {
	return &momentumAlgo{period: i}
}

// Run runs the algo.
func (a *momentumAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	data, _ := s.Data()
	event, _ := s.Event()
	symbol := event.Symbol()

	// prepare list of floats
	list := data.List(symbol)
	var closes []float64

	if len(list) < a.period {
		return false, fmt.Errorf("invalid value length for indicator momentum")
	}

	for i := 0; i < a.period; i++ {
		closes = append(closes, list[len(list)-i-1].Price())
	}

	// calculate momentum
	momentums := ta.Mom(closes, a.period)
	if len(momentums) > 0 {
		a.momentum = momentums[len(momentums)-1]
		// save the calculated momentum to the event metrics
		event.Add(fmt.Sprintf("momentum%d", a.period), a.momentum)

		return true, nil
	}
	return false, fmt.Errorf("no momentum calculated")
}

// Value returns the value of this Algo.
func (a *momentumAlgo) Value() float64 {
	return a.momentum
}

/* MFI */

// mfiAlgo is an algo which calculates the simple moving average.
type mfiAlgo struct {
	gbt.Algo
	period int
	mfi    float64
}

// Mfi returns a mfi algo ready to use.
func Mfi(i int) gbt.AlgoHandler {
	return &mfiAlgo{period: i}
}

// Run runs the algo.
func (a *mfiAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	data, _ := s.Data()
	event, _ := s.Event()
	symbol := event.Symbol()

	// prepare list of floats
	list := data.List(symbol)
	var closes []float64
	var highs []float64
	var lows []float64
	var volumes []float64

	if len(list) <= a.period {
		return false, fmt.Errorf("invalid value length for indicator mfi")
	}

	for i := 0; i <= a.period; i++ {
		closes = append(closes, list[len(list)-i-1].Price())
		highs = append(highs, list[len(list)-i-1].DayHigh())
		lows = append(lows, list[len(list)-i-1].DayLow())
		volumes = append(volumes, float64(list[len(list)-i-1].DayVolume()))
	}
	if len(closes) <= a.period {
		return false, fmt.Errorf("invalid value length for indicator mfi")
	}

	// calculate mfi
	mfis := ta.Mfi(highs, lows, closes, closes, a.period)
	if len(mfis) > 0 {
		a.mfi = mfis[len(mfis)-1]
		if a.mfi > 50 {
			// save the calculated mfi to the event metrics
			event.Add(fmt.Sprintf("mfi%d", a.period), a.mfi)
			return true, nil
		}
	}
	return false, fmt.Errorf("no mfi calculated")
}

// Value returns the value of this Algo.
func (a *mfiAlgo) Value() float64 {
	return a.mfi
}

/* MFIDivergence */
/* Note: Still in development */

// mfiAlgo is an algo which calculates the simple moving average.
type mfiDivAlgo struct {
	gbt.Algo
	period    int
	direction float64
}

// MfiDivergence returns an mfiDivergence algo ready to use.
func MfiDivergence(i int) gbt.AlgoHandler {
	return &mfiDivAlgo{period: i}
}

// Run runs the algo.
func (a *mfiDivAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	data, _ := s.Data()
	event, _ := s.Event()
	symbol := event.Symbol()

	// prepare list of floats
	list := data.List(symbol)
	var closes []float64
	var highs []float64
	var lows []float64
	var volumes []float64

	if len(list) < a.period {
		return false, fmt.Errorf("invalid value length for indicator mfi")
	}

	for i := 0; i < a.period; i++ {
		closes = append(closes, list[len(list)-i-1].Price())
		highs = append(highs, list[len(list)-i-1].DayHigh())
		lows = append(lows, list[len(list)-i-1].DayLow())
		volumes = append(volumes, float64(list[len(list)-i-1].DayVolume()))
	}

	// calculate mfi
	mfis := ta.Mfi(highs, lows, closes, closes, a.period)
	if len(mfis) > 0 {
		a.direction = mfis[len(mfis)-1]
		// save the calculated mfi to the event metrics
		event.Add(fmt.Sprintf("mfi%d", a.period), a.direction)

		return true, nil
	}
	return false, fmt.Errorf("no mfi calculated")
}

// Value returns the value of this Algo.
func (a *mfiDivAlgo) Value() float64 {
	return a.direction
}

/* Max */

// maxAlgo is an algo which calculates the highest close in period
type maxAlgo struct {
	gbt.Algo
	period int
	max    float64
}

// Max returns a max algo ready to use.
func Max(i int) gbt.AlgoHandler {
	return &maxAlgo{period: i}
}

// Run runs the algo.
func (a *maxAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	data, _ := s.Data()
	event, _ := s.Event()
	symbol := event.Symbol()

	// prepare list of floats
	list := data.List(symbol)
	var closes []float64

	if len(list) < a.period {
		return false, fmt.Errorf("invalid value length for indicator max")
	}

	for i := 0; i < a.period; i++ {
		closes = append(closes, list[a.period-i-1].Price())
	}

	// calculate high
	maxes := ta.Max(closes, a.period)
	if len(maxes) > 0 {
		a.max = maxes[len(maxes)-1]
		// save the calculated max value to the event metrics
		event.Add(fmt.Sprintf("mfi%d", a.period), a.max)
		return true, nil
	}
	return false, nil
}

// Value returns the value of this Algo.
func (a *maxAlgo) Value() float64 {
	return a.max
}

/* Min */

// minAlgo is an algo which calculates the highest close in period
type minAlgo struct {
	gbt.Algo
	period int
	min    float64
}

// min returns a min algo ready to use.
func Min(i int) gbt.AlgoHandler {
	return &minAlgo{period: i}
}

// Run runs the algo.
func (a *minAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	data, _ := s.Data()
	event, _ := s.Event()
	symbol := event.Symbol()

	// prepare list of floats
	list := data.List(symbol)
	var closes []float64

	if len(list) < a.period {
		return false, fmt.Errorf("invalid value length for indicator min")
	}

	for i := 0; i < a.period; i++ {
		closes = append(closes, list[a.period-i-1].Price())
	}

	// calculate high
	mins := ta.Min(closes, a.period)
	if len(mins) > 0 {
		a.min = mins[len(mins)-1]
		// save the calculated min value to the event metrics
		event.Add(fmt.Sprintf("mfi%d", a.period), a.min)
		return true, nil
	}
	return false, nil
}

// Value returns the value of this Algo.
func (a *minAlgo) Value() float64 {
	return a.min
}

/* number */

// numberAlgo is an algo which returns a const number
type numberAlgo struct {
	gbt.Algo
	number int
}

// min returns a min algo ready to use.
func Number(i int) gbt.AlgoHandler {
	return &numberAlgo{number: i}
}

// Run runs the algo.
func (a *numberAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	return true, nil
}

// Value returns the value of this Algo.
func (a *numberAlgo) Value() float64 {
	return float64(a.number)
}
