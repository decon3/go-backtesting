package algo

import (
	gbt "github.com/dirkolbrich/gobacktest"
)

type stoplossAlgo struct {
	gbt.Algo
	symbols []string
}

// HasHitStopLoss checks if the postion hit the stoploss
func HasHitStopLoss(symbols ...string) gbt.AlgoHandler {
	return &stoplossAlgo{symbols: symbols}
}

// Run runs the algo, returns the bool value of the algo
func (algo stoplossAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	portfolio, _ := s.Portfolio()
	event, _ := s.Event()

	// if no specified symbol use symbol of current event
	if len(algo.symbols) == 0 {
		symbol := event.Symbol()
		if _, ok := portfolio.HasHitStopLoss(symbol); !ok {
			return false, nil
		}

		return true, nil
	}

	// symbols specified
	var stoploss bool
	for _, symbol := range algo.symbols {
		if _, ok := portfolio.IsInvested(symbol); ok {
			stoploss = true
		}
	}

	return stoploss, nil
}

type targetAlgo struct {
	gbt.Algo
	symbols []string
}

// HasHitTarget check if the portfolio holds no position for the given symbol.
func HasHitTarget(symbols ...string) gbt.AlgoHandler {
	return &targetAlgo{symbols: symbols}
}

// Run runs the algo, returns the bool value of the algo
func (algo targetAlgo) Run(s gbt.StrategyHandler) (bool, error) {
	portfolio, _ := s.Portfolio()
	event, _ := s.Event()

	// if no specified symbol use symbol of current event
	if len(algo.symbols) == 0 {
		symbol := event.Symbol()
		if _, ok := portfolio.HasHitTarget(symbol); ok {
			return false, nil
		}

		return true, nil
	}

	// symbols specified
	var invested bool
	for _, symbol := range algo.symbols {
		if _, ok := portfolio.HasHitTarget(symbol); ok {
			invested = true
		}
	}

	return !invested, nil
}
