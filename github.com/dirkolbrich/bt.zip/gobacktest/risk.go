package gobacktest

// RiskHandler is the basic interface for accessing risks of a portfolio
type RiskHandler interface {
	EvaluateOrder(OrderEvent, DataEvent, map[string]Position, Casher, Pricer) (*Order, error)
}

// Risk is a basic risk handler implementation
type Risk struct {
	portfolioRisk float64
	tradeRisk     float64
	profit        float64
}

func NewRiskManager(portfolioRiskFactor float64, tradeRiskFactor float64, profitFactor float64) *Risk {
	risk := Risk{
		portfolioRisk: portfolioRiskFactor,
		tradeRisk:     tradeRiskFactor,
		profit:        profitFactor,
	}
	return &risk
}

// EvaluateOrder handles the risk of an order, refines or cancel it
func (r *Risk) EvaluateOrder(order OrderEvent, data DataEvent, positions map[string]Position, casher Casher, price Pricer) (*Order, error) {
	o := order.(*Order)
	if o.Direction() == BOT { // not exiting an existing position
		o.orderType = LimitOrder
		o.limitPrice = price.DayHigh()
		o.qty, o.stoploss, o.target = r.CalculateSize(o.Limit(), casher.Cash())
	}
	return o, nil
}

func (r *Risk) CalculateSize(price float64, cash float64) (qty int64, stoploss float64, target float64) {
	stoploss = price - (r.tradeRisk * price)
	target = price + (r.profit * price)
	trisk := price - stoploss
	prisk := r.portfolioRisk * cash
	qty = int64(prisk / trisk)
	for {
		if float64(qty)*price > cash {
			qty--
		} else {
			break
		}
	}
	if qty < 0 {
		return 0, 0, 0
	} else {
		return int64(qty), stoploss, target
	}
}
